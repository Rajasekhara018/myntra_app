import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CategoryData, DataserviceService } from '../services/dataservice.service';
@Component({
  selector: 'app-heels',
  templateUrl: './heels.component.html',
  styleUrls: ['./heels.component.scss']
})
export class HeelsComponent implements OnInit {


  siteData = new Array<CategoryData>();
  constructor(public dservice: DataserviceService,
    private snackbar: MatSnackBar) { }

  ngOnInit(): void {

    this.dservice.getData().subscribe(data=>{
      this.siteData=data;
      console.log(data)
    });
    this.filterCategory(this.siteData)
  }
  addToWishList(data:CategoryData){

    this.dservice.wlJson.push(data);
    this.dservice.wlCount++;
    this.snackbar.open("addtwishlist","Dismiss",{duration:3000})
  }
  addTocart(name: CategoryData) {
    if (name) {
      this.dservice.cartJson.push(name);
      this.dservice.cartCount ++;
      this.snackbar.open('Item Added to Cart', 'Dismiss', {duration: 3000})
    }
  }


  filterCategory(cat:CategoryData[]):CategoryData[]{

return this.siteData.filter(p =>p.subcategory=='heels');
console.log(this.siteData)


  }

}

