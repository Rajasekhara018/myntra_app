import { Component, OnInit } from '@angular/core';
import { LoginObj } from '../services/dataservice.service';
import { CategoryData, DataserviceService } from '../services/dataservice.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SimpleSnackBar } from '@angular/material/snack-bar';
import { CdkHeaderCellDef } from '@angular/cdk/table';
import { Observable, repeatWhen } from 'rxjs';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {


  creditPay = [
    { "mastercardno": "5123453314128721", "valithru": 12 / 21, "cvv": 324, "imgurl": "../../assets/card-imges/mastercard-logo.jpg" },
    { "mastercardno": "5113456317028738", "valithru": 12 / 25, "cvv": 415, "imgurl": "../../assets/card-imges/mastercard-logo.jpg" },
    { "mastercardno": "5627456814028734", "valithru": 12 / 28, "cvv": 467, "imgurl": "../../assets/card-imges/mastercard-logo.jpg" },
    { "visacardno": "4123653314728723", "valithru": 11 / 20, "cvv": 764, "imgurl": "../../assets/card-imges/visacard.jpg" },
    { "visacardno": "4223653314728725", "valithru": 11 / 22, "cvv": 674, "imgurl": "../../assets/card-imges/visacard.jpg" },
    { "visacardno": "4323653314798721", "valithru": 11 / 28, "cvv": 812, "imgurl": "../../assets/card-imges/visacard.jpg" },
    { "rupaycardno": "6123653314728723", "valithru": 10 / 20, "cvv": 543, "imgurl": "../../assets/card-imges/Rupay-Logo.jpg" },
    { "rupaycardno": "6323653314528724", "valithru": 10 / 22, "cvv": 523, "imgurl": "../../assets/card-imges/Rupay-Logo.jpg" },
    { "rupaycardno": "6313653314529722", "valithru": 10 / 26, "cvv": 253, "imgurl": "../../assets/card-imges/Rupay-Logo.jpg" },
    { "americanexpno": "3323653314528724", "valithru": 9 / 22, "cvv": 321, "imgurl": "../../assets/card-imges/american express-logo.jpg" },
    { "americanexpno": "3323653314528724", "valithru": 9 / 29, "cvv": 371, "imgurl": "../../assets/card-imges/american express-logo.jpg" },
    { "americanexpno": "3543653314528782", "valithru": 9 / 21, "cvv": 651, "imgurl": "../../assets/card-imges/american express-logo.jpg" }]


  netbank = [{ cardname: 'HDFC' }, { cardname: 'SBI' }, { cardname: 'ICICI' }, { cardname: 'AXIS' }, { cardname: 'KOTAK' }, { cardname: 'PNB' }]
  date = new Date;
  hide = true;
  oredrId = "MY1234518"
  cardnumber: string;
  username: string;
  cvvnumber: number;
  validthru: number;
  UPIID: string;
  WalletID: string;
  NetbankingID: string;
  showspinner = false;
  addressObj: LoginObj;


  page0: boolean;
  page1: boolean;
  page2: boolean;
  page3: boolean;
  ta: string;//total amount
  cardImg: any;

  bankname = 'hdfc';
  RandId = Math.trunc(Math.random()*10000000)
  iscardValid = false;// error msg

  regUsers: Array<LoginObj> = new Array<LoginObj>();

  constructor(private router: Router, public dservice: DataserviceService,) { }

  ngOnInit(): void {
    this.addressObj = new LoginObj();
    this.page0 = true;
     let t = JSON.parse(localStorage.getItem('ta'))
    // let t = localStorage.getItem('ta');
    this.ta = t != null ? JSON.parse(t) : '';
    // this.filteredOptions = this.mycontrol.valueChanges
  }

  restrictChar(event: any) {
    if (event.target.value.length === 0 && event.key === "0") {
      event.preventDefault();
    }
  }

  clickMessage = '';
  clickMessage1 = '';

  onClickMe() {
    this.clickMessage = 'HDFC';
  }
  onClickMe1() {
    this.clickMessage1 = 'SBI';
  }

  cardFormat(value: string) {
    if (value.startsWith('3')) {
      this.cardImg = './../assets/card-imges/american express-logo.jpg';
    }
    if (value.startsWith('4')) {
      this.cardImg = '../../assets/card-imges/visacard.jpg';
    }
    if (value.startsWith('5')) {
      this.cardImg = '../../assets/card-imges/mastercard-logo.jpg';
    }
    if (value.startsWith('6')) {
      this.cardImg = './../assets/card-imges/Rupay-Logo.jpg';
    }
  }
  checkCardno() {
    return false;
  }
  // proceedToPay(paymentform:LoginObj){
  //   this.regUsers.push(paymentform)
  //   localStorage.setItem('paymentformData', JSON.stringify(this.regUsers));
  //   this.page0 = false;
  //   this.page1 = true;
  //   this.showspinner = true;
  //   setTimeout(() => {
  //     this.showspinner=false
  //     this.page1 = false;
  //     this.page2 = true;
  //     this.proceedToPay1();
  //   }, 2000)

  // }

  keyPressNumbers(event:any){
    // console.log(event);
    var charCode = (event.which) ? event.which : event.keyCode;

  if((charCode ==(48-0) || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;


    }
  }


  proceedToPay(paymentform: LoginObj) {

    this.page0 = false;
    this.page1 = true;
    this.iscardValid=true
    if (this.addressObj.cardnumber && this.addressObj.validthru && this.addressObj.cvvnumber) {
      for (let i = 0; i <= this.creditPay.length; i++) {
        if (this.addressObj.cardnumber === this.creditPay[i]?.mastercardno || this.addressObj.cardnumber === this.creditPay[i].visacardno || this.addressObj.cardnumber === this.creditPay[i]?.americanexpno || this.addressObj.cardnumber === this.creditPay[i].rupaycardno
          && this.addressObj?.cvvnumber === this.creditPay[i].cvv && this.addressObj.validthru === this.creditPay[i].valithru) {
          this.page1 = true;

          this.showspinner = true;
          setTimeout(() => {
            this.showspinner = false
            this.page1 = false;
            this.page2 = true;
            this.proceedToPay1();
          }, 2000)
        }
        // this.page1 = true;
// else{
//   this.iscardValid = true;
// }

      }



    }


    // this.showspinner = true;
    // setTimeout(() => {
    //   let check = this.checkCardno();
    //   if (check) {
    //     this.showspinner = false
    //     this.page1 = false;
    //     this.page2 = true;
    //     this.proceedToPay1();
    //   }
    //   else {
    //     this.page0 = false;
    //     this.page1 = true;
    //     this.page2 = false;
    //     this.page3 = false;
    //     this.iscardValid = true;
    //   }
    // }, 3000);
  }

  proceedToPay1() {
    this.showspinner = false;
    setTimeout(() => {
      this.showspinner = false
      this.page0 = false;
      this.page1 = false;
      this.page2 = false;
      this.router.navigate(["processpay"])

    }, 3000);
  }

  previous() {
    this.page1 = false;
    this.page0 = true;
  }
  close() {
    this.router.navigate(["landing"])
  }


}











